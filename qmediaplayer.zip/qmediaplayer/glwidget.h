#ifndef GLWIDGET_H
#define GLWIDGET_H


class GLWidget : public QGLwidget
{
public:
    GLWidget();
};

#endif // GLWIDGET_H
